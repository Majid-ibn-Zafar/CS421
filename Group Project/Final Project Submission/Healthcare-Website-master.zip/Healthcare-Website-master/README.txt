

This project is started by running bin.py using the python interpreter:

python bin.py

The application is accessed vi localhost on port 5000:

http://127.0.0.1:5000/

If you need to create a user for yourself:

http://127.0.0.1:5000/newUser

On that page, I recommend you change the UserType  to "provider"
    as the patient type has less options...
    note that the NAME field and USERNAME field are different

After creating the user, navigate back to http://127.0.0.1:5000/
and log in